export const PRODUCTS_MOCK = [
    {

      
      id: 1,

    },
  

  ];


  


  